---
name: pdf2skills
description: 把 PDF 书籍转成 Claude Code 可直接调用的 skill（已内置《代码大全》等示例产物）。当用户说「把这本 PDF 蒸馏成 skill」「把 PDF 转成 skill」「pdf2skills」「用 pdf2skills 处理这个 PDF」时使用。调用方式是命令行 python run_pipeline.py，详见 README.md。
---

# pdf2skills（PDF → Skills）

把 PDF 书籍转换成 Claude Code 可调用的 skill 集合。本工具是 Python 脚本工具包，这个 SKILL.md 是为提供中文触发入口而新建的。

## 调用方式

```bash
python run_pipeline.py <PDF路径>
```

## 关键文件
- `README.md` — 用法说明
- `run_pipeline.py` — 主流水线入口
- `skill_generator.py` / `knowledge_fusion.py` / `semantic_density.py` / `router_generator.py` / `glossary_extractor.py` — 核心模块
- `skills_samples/` — 已蒸馏的《代码大全》示例产物（参考用）
- `skills2app/` — 附带的其他通用 skill

## 输出
在指定目录生成一组带 `SKILL.md` 的 skill 文件夹，复制到 `~/.claude/skills/`（即 `C:\Users\<你的用户名>\.claude\skills\`）即可被 Claude Code 调用。
