---
name: autoharness
description: Claude Code 的自学习 skill 层——从你的真实对话 session 中自动蒸馏出 skill、在工作中持续更新它们，并淘汰不再适用的。当用户说「自动记录我的工作流」「从刚才的对话生成 skill」「让 Claude 自己学我的习惯」「autoharness」「self-learning skill」时使用。详细安装与用法见 README.md 和 AGENTS.md。
---

# Autoharness（自学习 skill 层）

> 本工具原本是 Claude Code **插件（plugin）**，不是单文件 skill。这个 SKILL.md 是为提供中文触发入口而新建的。

## 它做什么
- 从你真实的 Claude Code session 中自动**蒸馏**出可复用的 skill
- 随着你持续工作，自动**更新**这些 skill
- 自动**淘汰**过时、不再被触发的 skill

## 怎么用
完整安装与配置见：
- `README.md` — 项目说明与安装步骤
- `AGENTS.md` — agent 行为约定
- `.claude-plugin/` — 插件清单
- `agents/curator.md`、`agents/reflector.md` — 子 agent 定义
- `src/`、`hooks/`、`tools/` — 实现代码
