# Format-only 示例

这个目录只演示文件组织方式，不用于展示真实蒸馏效果。

中文产物参考 `templates/author-corpus/zh/`，英文产物参考 `templates/author-corpus/en/`。

真实蒸馏请准备至少 20 篇完整文章。

为了避免版权问题，这里不附带任何第三方作者的原文语料。
