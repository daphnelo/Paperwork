# Documentation Health Maintenance

Keep the skills directory from degrading: no broken links, duplicated meaning, lossy accumulation, fake file boundaries, or unrelated content loaded together.

**Core principle: line counts are signals, not commands.** A file boundary is justified by an independent loading, ownership, or generation reason. Short files may stay separate when tasks select them independently; long files may stay whole when every real task needs the whole meaning.

## Semantic Ownership and Local Actionability

Definitions, state transitions, normative conditions, and multi-step procedures normally have one complete semantic owner. A consumer may repeat the smallest task-specific trigger, immediate action, and current-task acceptance responsibility needed to act without exploratory navigation, then link to the owner before full detail is required. Do not make either extraction or repetition the default objective.

Judge a repeated block from the real task path:

1. **Semantic authority** — would the copy become a second place that can redefine the rule?
2. **Change covariance** — must every copy change whenever the owner changes, or can the local hook remain valid?
3. **Read-path cost** — would a link force a common task to load another file merely to discover its next action?
4. **Drift consequence** — duplicated business authority, safety behavior, or stop conditions cost more than duplicated orientation.
5. **Distribution boundary** — generation is justified when a target must be independently delivered or independently used, not merely because text repeats.

Prefer one owner plus local action hooks inside one Skill. A complete repeated rule or workflow is exceptional: task/PR evidence must show that full repetition costs less than navigation, loading, or generation after drift risk is included. Generated copies have one source, are not hand-edited, and require deterministic equality/drift validation. Use judgment rather than a sentence quota, score, marker, or file-count target.

For business leaf / Gotcha pairs, apply [`workflows/rule-update/business-truth.md` § Business Leaf and Gotcha Ownership](rule-update/business-truth.md#business-leaf-and-gotcha-ownership) before ordinary dedup or split decisions. Flag three forms of owner drift: the same complete business rule appears in both files; stable business truth exists only inside a Gotcha; or volatile classes, fields, endpoints, storage details, and repair recipes have entered the leaf. Reconcile the complete normative meaning into the leaf, keep the implementation failure in the Gotcha, and leave only the smallest cross-link needed for local action.

## When to Run

- After a Rule Update owner changes a durable file, quickly check the modified file line counts
- Proactive maintenance: when files feel "hard to navigate" or "too long to want to read"
- **Not required** after every small change

## Step 1: Size Scan

Check line counts for all files under `skills/{{NAME}}/` and flag those that may need attention:

| File type | Reference range | Triggers evaluation | Fragment signal |
|---|---|---|---|
| `SKILL.md` | description ≤ 25 + body ≤ 90 lines (dual budget) | description > 25 (split intent clusters) or body > 90 (move detail) | — |
| `rules/*.md` | 50–200 lines | > 200 lines | < 30 lines |
| `workflows/*.md` | 30–150 lines | > 150 lines | < 15 lines |
| `references/*.md` | 50–300 lines | > 300 lines | < 30 lines |
| Thin shells | Routing + compatibility notes only | Rule/workflow bodies or project-specific process detail | — |

Note: these numbers are **reference values**, not hard thresholds. A 250-line rules file with a single coherent topic is perfectly fine to keep.

## Step 1b: Accumulation Check (tiered triggers — when to spend tokens)

Accumulation rot is not limited to gotchas, but the cost of detecting it is not uniform. A full agent-led reorganization of a 300-line file costs real tokens; the same file checked by `grep` costs nothing. The discipline below uses **three tiers** of trigger so the expensive scan only runs when the cheap one has already flagged something or when accumulated pressure has crossed a real threshold.

### The three tiers

| Tier | When it runs | Who runs it | Cost |
|---|---|---|---|
| **0 — bash gate** | Every `smoke-test.sh` run (every commit if wired into a hook) | `smoke-test.sh § 2a` — `grep "^## " <file> | sort | uniq -d` | ~0 tokens (bash) |
| **1 — AAR similarity scan** | Whenever the Agent is about to add or extend an entry through `workflows/update-rules.md` § Reconciliation Gate | The same Agent that just ran the task - context is already loaded | ~few hundred tokens (targeted scan of 3-5 candidates, not the whole file) |
| **2 — full reorganization pass** | Only when a Tier-2 trigger fires (see below) | Agent reads the full file and restructures | ~thousands of tokens |

**Tier 2 triggers** — any one of these is enough; do not run Tier 2 just because it has been a while:

- File entry count > 25 for `references/gotchas.md` / `references/*pitfall*.md`
- File line count > 80% of cap (i.e. > 320 lines when cap is 400)
- `rules/*.md` has > 25 bullet-level rules
- `references/*.md` (non-gotchas) has > 40 entries
- Smoke-test Tier-0 flagged a duplicate **and** `.maintenance-log.yaml` shows the previous Tier-2 pass was > 30 days ago (a single dup is normal noise; recurring dups in a recently-cleaned file signal real drift). No ledger entry for the file = "no baseline yet" = treat the dup as a Tier-2 baseline trigger. See Step 7 for the ledger schema.
- A user explicitly asks for cleanup ("整理一下", "dedup gotchas", "reorganize this file")

Do **not** auto-fire Tier 2 from `smoke-test.sh`. Smoke-test should stay deterministic, fast, and free; Tier 2 lives in this workflow, run on demand.

### What Tier 2 does (the full pipeline)

Run these passes **in order** — they form a "categorize before splitting" pipeline so you do not split prematurely:

1. **Dedup scan (always first)** — surface real duplicates before any reorganization.
   - Exact-heading duplicates: `grep "^## " <file> | sort | uniq -d` lists every `##` heading that appears more than once. Same heading recorded twice = same entry copy-pasted; merge or delete one.
   - Topic-tag duplicates: `grep -oP '\*\*\[([^\]]+)\]' <file> | sort | uniq -c | sort -rn` lists `**[topic]**` tag frequency; tags with high counts are merge candidates.
   - Near-duplicates (different wording, same root cause) — agent reads the candidate set and decides; this is where Tier 2 spends most of its tokens, and why it is rare.
2. **Staleness scan** — are any entries about technology/patterns that have since been removed from the project? Delete stale entries or mark `<!-- DEPRECATED: reason, YYYY-MM -->`.
3. **Categorize (before splitting)** — if a file still has > 10 entries after dedup, group them under H2 categories before considering a split. This usually buys another 2–3× growth before a physical split is needed, and makes future dedup scans O(category) instead of O(file) — which lowers Tier-1 token cost too. **Categorization differs by file type:**

   - **Entries-style files** (`references/gotchas.md` / `references/*pitfall*.md`): promote frequent `**[topic]**` tags to `## CategoryName` headings; rename individual entries from `## **[topic]** title` to `### **[topic]** title` under the right category. The tag frequency grep `grep -oP '\*\*\[([^\]]+)\]' <file> | sort | uniq -c | sort -rn` tells you which tags deserve promotion.

   - **Rules files** (`rules/*.md`): rules don't carry `**[topic]**` tags, so categorize by **the natural axis the rules already divide on**. Pick exactly one axis per file — mixing axes makes the file harder to navigate, not easier; genuinely needing two axes is a split signal (Step 6), not a categorization signal. Three common axes:
     - **Module / surface boundary** — e.g. `web` vs `biz` vs `core` vs `dal` for a backend; `routes` vs `forms` vs `data-flow` for a frontend.
     - **Responsibility / lifecycle phase** — e.g. routing → validation → response wrapping → exception handling for an HTTP layer.
     - **Trigger scenario** — e.g. "when adding a new Controller" / "when changing an existing contract" / "when extending DAL".

     Re-anchor scattered bullets under the chosen H2. If a single H2 grows past ~30 bullet-rules, extract that section into its own sub-rule file via Step 6 instead of letting one category dominate.
4. **Structural scan** — after categorizing, re-anchor any remaining orphan entries under the correct H2 section.
5. **Tag audit** — do all entries carry `**[topic]**` tags? If > 50% are untagged, tag them in this same pass while attention is on the file.
6. **Split (last resort)** — only after dedup + categorize. Split when a category has a genuinely different audience/task path and the route or selecting index can load it without all siblings. A short result is acceptable if it is independently selected; a long result is wrong if every caller still co-loads all siblings.
7. **Update the maintenance ledger (closure gate)** — Tier-2 is incomplete until the ledger is updated. The ledger is the only mechanism that distinguishes "a duplicate in this file is normal noise" from "this file has drifted enough to need a full reorg"; without it, the > 30-days trigger in the list above has no clock and the whole tier model degrades to agent guesswork.

   - **Location:** `.maintenance-log.yaml` at skill root — `skills/<name>/.maintenance-log.yaml` downstream, `./.maintenance-log.yaml` self-hosting.
   - **Schema** (one entry per long-lived file the project intends to maintain at Tier-2; `path` required, `last_tier2` required once a pass has run, the rest advisory):
     ```yaml
     files:
       - path: references/gotchas.md
         last_tier2: 2026-04-15
         passes_run: [dedup, categorize]   # which steps 1–6 above actually executed
         entries_after: 18                  # grep -c '^## ' after the pass; baseline for next drift check
     ```
   - **Write step:** after completing steps 1–6 on a file, run `grep -c '^## ' <file>` for `entries_after`, list executed passes in `passes_run` (skipped passes that produced an empty diff still count as "run"; not-attempted passes are omitted), set `last_tier2: $(date +%Y-%m-%d)`, then write or replace the entry under `files:`.
   - **Read step:** `smoke-test.sh § 2a` consults the ledger on every detected duplicate `##` heading. No entry → "first-time dup, run Tier-2 baseline". `last_tier2` > 30 days → "Tier-2 stale, run full reorg". `last_tier2` ≤ 30 days → "dedup this entry only, skip full Tier-2". The duplicate itself always fails (verbatim copy-paste is always wrong); the ledger only governs whether *a full reorg* is recommended on top of the dedup.
   - **Stale ledger entries:** when this Tier-2 pass discovers a `path` that no longer exists in the project, remove the entry in the same pass. The ledger should never reference deleted files.

### Token-cost intuition for maintainers

- A project that adds ~5 new gotchas per month and is never reorganized will hit Tier 2 in about half a year. That is the expected cadence — not "weekly", not "yearly".
- Tier 1 runs at every closure event with a new gotcha. Most of those find no match and add the entry; a few find a near-match and merge. Both are cheap.
- Tier 0 runs at every commit. Free.

If you find yourself running Tier 2 more than once a quarter on the same file, the file is the wrong shape — split it (step 6 above) so each subfile stays under its own threshold.

A gotchas file that's too long to scan quickly defeats its purpose — the whole point is "brief, scannable list." The same applies to any file that agents read as part of task routing.

> **Note (2026-05-19):** an earlier draft of this workflow added a "Step 1c: External Fact Freshness" requiring authors to hand-mark each vendor/tool/runtime fact with `<!-- external-fact: verified=YYYY-MM-DD source=... -->` and run `check-external-facts.sh`. That section was removed along with the script - no project ever enforced the marker, so the script ran empty. If a fact is stale, let the next task that touches it use `workflows/rule-update/knowledge-reconciliation.md` to correct or retire it: human re-read at the right moment beats a marker no one writes.

## Step 2: Independent Load-Reason Audit

Run this before split/merge decisions and after route changes. For every candidate knowledge read or activation edge, record a compact matrix:

| File | Real task/route | Why needed at task start | Loaded independently? | Conditional alternative |
|---|---|---|---|---|

Judge from real call paths, not headings or desired symmetry:

1. **Independent selection** — name a real request that loads this file without every sibling.
2. **Action change** — state what reading it changes next; background that changes nothing is not a load reason.
3. **Timing** — if content is needed only at mutation, testing, Closure, Large-plan analysis, domain reasoning, or another branch, load it at that first action-changing boundary rather than at task routing.
4. **Co-load test** — if all real callers load and modify two files together, prefer one file. Separate ownership or mechanical generation can preserve storage boundaries, but runtime routing still should not force unrelated co-loading.
5. **Index test** — create an index only when multiple independent files exist and task signals let the index select the next read. A passive file list is not an index with activation value.

Orphan/reachability scripts cannot prove this audit: they show that a path exists, not that its content is independently useful.

## Step 3: Evaluate — Should You Split?

When a file exceeds the reference range, answer these questions:

1. **Are the topics semantically separable?** — removing one does not change understanding of the other.
2. **Do real tasks select them differently?** — name the before/after route reads.
3. **Can each part stand alone?** — no hidden need to load siblings to interpret it.
4. **Does the split reduce irrelevant context?** — not merely make the directory look organized.

All four "yes" → splitting has value. Any "no" → keep one file and improve headings/navigation instead.

### When NOT to Split

- File is long but highly coherent
- Splitting would force readers to jump between two files to understand one concept
- File barely exceeds the reference value with no actual navigation difficulty
- Every real route would load all resulting files together

### Executing a Split

1. **Identify boundaries** — find independent topic blocks (usually H2 headings)
2. **Name new files** — rules: `*-rules.md`, workflows: verb-noun, references: noun-based
3. **Migrate content** — move to new files, keep heading levels reasonable
4. **Update routing** — route directly to independently selected leaves; add a selecting index only when task signals need it; then run `scripts/sync-routing.sh`
5. **Update referrers** — other rule files that cross-reference the split files
6. **Verify** — no broken links, no duplicated content, nothing left behind

## Step 4: Evaluate — Should You Merge?

When fragment files are detected, answer these questions:

1. **Do all real callers load them together?** — compare routes/workflows/index branches, not file size.
2. **Do they form one decision surface?** — definitions/conditions in one are needed to interpret the other.
3. **Is there no independent ownership/generation contract that requires separate storage?**
4. **Will headings keep the merged content navigable?**

All four "yes" → merge. Otherwise keep the boundary and document its independent load/ownership reason.

### Executing a Merge

1. **Merge** — combine content into one file, use H2 headings to separate original topics
2. **Check navigation** — line count triggers review, but coherent content may exceed the reference range
3. **Update references** — all locations that referenced the original files
4. **Clean up** — delete the original files

## Step 5: Semantic Before/After Reconciliation

After deduplication, categorization, compression, split, or merge, compare the durable meaning before checking links:

1. inventory load-bearing definitions, applicability conditions, boundaries/counterexamples, and reasons in the original;
2. map each item to its destination after the edit;
3. verify none was dropped, silently broadened/narrowed, or separated from context needed to interpret it;
4. verify symptoms sharing one root cause remain integrated rather than becoming parallel entries;
5. verify each resulting file still has the independent load reason recorded in Step 2.

### Source-Preserving User Input

For user-brainstorm input, user wording is source evidence, not draft prose that the Agent is expected to improve. Before any synthesis, preserve the original question/options and every decision-bearing user clause. If the wording is already clear, keep it unchanged. Readability editing is optional and limited to punctuation, obvious typo repair, grammar, or word order; it must not add, delete, merge, generalize, soften, or strengthen a clause. Preserve the speech act and force, actor/ownership, timing/commitment, uncertainty, emphasis, definition, applicability, boundary, negation/rejected direction, rationale/consequence, authority, scope, and `proposed | confirmed | superseded` or evidence-needed status. A stop request, responsibility handoff, deadline/promise, confidence limit, or repeated emphasis is semantic content, not disposable tone.

An Agent synthesis may follow only as a clearly labeled derived interpretation; it must never become the sole normative record. Keep a concise or high-risk user statement verbatim next to that interpretation. For longer input, retain every decision-bearing original clause before any compact derived summary. Each source clause must then be preserved verbatim, minimally normalized under the rule above, moved to an exact `owner#section`, or explicitly deleted because its premise is invalid. A move or summary is equivalent only when meaning, applicability/authority, pragmatic force, and normal activation timing are all equivalent; if a fresh Agent could make a different decision, retain the source wording or return for user clarification.

This is a judgment gate, not a request for a semantic-lint script. Save the compact before/after load matrix and meaning inventory in the task/PR evidence when the reorganization is substantial.

## Step 6: Reference Integrity Check

Run after any split, merge, rename, or deletion of files under `skills/{{NAME}}/`:

```bash
bash skills/{{NAME}}/scripts/sync-routing.sh {{NAME}} --check
bash skills/{{NAME}}/scripts/smoke-test.sh {{NAME}} --phase 8
(cd skills/{{NAME}} && bash scripts/audit-orphans.sh)
(cd skills/{{NAME}} && bash scripts/route-reachability.sh)
bash skills/{{NAME}}/scripts/route-health.sh {{NAME}}
```

For a two-root skill, run the last two structural checks once from each root with `--namespace skill|code --routing <skill-root>/routing.yaml`; namespace identity is part of reachability.

- [ ] All links in generated SKILL.md Always Read and the Common Tasks action hook are valid; exact route paths validate from `routing.yaml`
- [ ] All `workflows/*.md` "Read First" sections reference existing files
- [ ] Cross-references between rules/references files point to valid targets
- [ ] Thin shells still point to the current `skills/{{NAME}}/SKILL.md` or documented multi-skill router, and generated bootstraps match `routing.yaml`
- [ ] No orphaned files (file exists but no entry links to it)
- [ ] `route-health.sh` shows no new routing-quality smells (no/weak triggers, overlap, language) — advisory
- [ ] No duplicated content (each rule maintained in exactly one place)
- [ ] Complete definitions/procedures have one owner; consumers retain only justified local action hooks, and any full-copy exception has task evidence
- [ ] Business leaf / Gotcha pairs have no complete-rule duplication, business-truth owner inversion, or implementation-detail leakage into the leaf
- [ ] If a file was deleted, no other file still references it

## Completion Criteria

- Evaluated over-threshold files and made a **reasoned judgment** to keep or split
- Every changed file boundary and route read has an independent load/ownership/generation reason
- Before/after load matrix proves conditional content moved off unrelated task paths
- Dedup/split/merge/compression passed semantic before/after reconciliation
- If any file was split, merged, renamed, or deleted, reference integrity check passes
- `routing.yaml` and SKILL.md navigation match current file structure
